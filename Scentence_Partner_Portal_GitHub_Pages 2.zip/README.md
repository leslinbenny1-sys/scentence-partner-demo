# Scentence Partner Portal — Demo

## GitHub Pages setup

1. Create a new GitHub repository, for example `scentence-partner-demo`.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. GitHub will provide your public demo URL.

### Demo accounts
- Owner: `owner` / `scentence123`
- Manager: `celin` / `scentence123`
- Partner: `kevin` / `kevin123`

**Important:** This is only a visual/demo prototype. Do not enter real customer information or real passwords. The production version needs real authentication and a database with server-side security/RLS.
