SCENTENCE PARTNER PORTAL V1 — DEMO

This is a visual prototype only. It is NOT safe for real customer data yet.

Demo logins:
Owner: owner / scentence123
Manager: celin / scentence123
Partner: kevin / kevin123

Next production step:
Connect a real authentication/database service (e.g. Supabase Auth + Postgres), enforce role-based access and row-level security, then deploy this portal to a separate subdomain such as partners.scentenceparfum.com.
